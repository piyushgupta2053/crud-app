
import notf from "../Assets/Image/notf.jpg";
const NotFound = () =>{
    return(
        <>
      <img src={notf} alt="srcnotFound" style={{width:"30%" ,margin:"80px 0 0 35%"}} />
      </>
    )
}
export default NotFound;